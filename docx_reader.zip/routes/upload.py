from flask import Blueprint, render_template, request, current_app
from werkzeug.utils import secure_filename
from docx_reader import read_questions_from_docx
from datetime import datetime
import os, sqlite3,json
import random
import string

upload_bp = Blueprint('upload', __name__)

# Tạo thư mục uploads nếu chưa tồn tại
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Hàm kiểm tra đuôi file hợp lệ
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'docx'

# Hàm tạo hậu tố ngẫu nhiên gồm 12 ký tự a-z và 0-9
def generate_random_suffix(length = 6):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

import sqlite3
from datetime import datetime
import json

def add_dethi_to_db(id: str, time: int, id_dapan: int, questions: list, db_path: str = 'student_info.db'):
    time_create = datetime.now().isoformat()
    noidung = json.dumps(questions, ensure_ascii=False)  # giữ Unicode, dấu tiếng Việt
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute('''
        INSERT INTO dethi (id, time, id_dapan, noidung, time_create)
        VALUES (?, ?, ?, ?, ?)
    ''', (id, time, id_dapan, noidung, time_create))
    conn.commit()
    conn.close()


@upload_bp.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'Không tìm thấy file', 400
        file = request.files['file']
        if file.filename == '':
            return 'Chưa chọn file', 400
        if file and allowed_file(file.filename):
            original_name, ext = os.path.splitext(secure_filename(file.filename))
            random_suffix = generate_random_suffix()
            new_filename = f"{original_name}_{random_suffix}{ext}"
            filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], new_filename)
            file.save(filepath)
            # Đọc câu hỏi từ file đã lưu
            questions = read_questions_from_docx(filepath,random_suffix)
            time = 30 #phut
            id_dapan = 0
            add_dethi_to_db(id=random_suffix, time=time, id_dapan=id_dapan, questions=questions)
            return render_template('preview.html', questions=questions, id_dethi=random_suffix)
    return render_template('upload.html')
